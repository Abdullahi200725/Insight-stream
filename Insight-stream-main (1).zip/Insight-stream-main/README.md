# Insight-stream
This React app uses NewsAPI to fetch and display the latest news headlines from India. It shows article titles, descriptions, and links, with a clean TailwindCSS design. Simple, fast, and useful for staying updated without visiting multiple sites 🚀
